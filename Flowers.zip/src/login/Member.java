/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package login;

/**
 *
 * @author dgq
 */
public class Member {
    private String Name;
    private String pwd;
    private String truename;
    private String sex;
    private String phone;
    private int qq;
    private String address;
    private String email;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getTruename() {
        return truename;
    }

    public void setTruename(String truename) {
        this.truename = truename;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getQq() {
        return qq;
    }

    public void setQq(int qq) {
        this.qq = qq;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public Member(){
        
    }
    public Member(String name,String pwd,String truename,String sex,String phone,int qq,String address,String email){
        this.Name=name;
        this.pwd=pwd;
        this.truename=truename;
        this.sex=sex;
        this.phone=phone;
        this.qq=qq;
        this.address=address;
        this.email=email;
    }
}
