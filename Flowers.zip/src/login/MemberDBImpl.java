/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package login;
import java.sql.*;
/**
 *
 * @author dgq
 */
public class MemberDBImpl {
    public boolean mbInsert(Member member){
        boolean flag = false;
        DBConnection instance = new DBConnection();
        Connection result = instance.getConn();
        if(result!=null){
            String sql = "insert into user_login values(?,?,?,?,?,?,?,?)";
            try {
                PreparedStatement ppsm = result.prepareStatement(sql);
                ppsm.setString(1,member.getName());
                ppsm.setString(2,member.getPwd());
                ppsm.setString(3,member.getTruename());
                ppsm.setString(4,member.getSex());
                ppsm.setString(5, member.getPhone());
                ppsm.setInt(6, member.getQq());
                ppsm.setString(7, member.getAddress());
                ppsm.setString(8, member.getEmail());
                int line = ppsm.executeUpdate();
                if(line == 1){
                    flag = true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

}
