/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package login;
import java.sql.*;
/**
 *
 * @author dgq
 */
public class DBConnection {
    private Connection conn=null;
    public DBConnection(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433; databaseName=Flowers";
            this.conn=DriverManager.getConnection(url,"java","p6666");
        } catch (Exception e) {
        }
    }
     Connection getConn() {
         //To change body of generated methods, choose Tools | Templates
        return this.conn;
    }
}
